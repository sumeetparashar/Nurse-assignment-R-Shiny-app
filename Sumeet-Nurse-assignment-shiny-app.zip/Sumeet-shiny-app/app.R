# if an environment variable DOCPLEXCLOUD_URL is set, use that as the base url,
# otherwise use the default public docplexcloud URL.
baseUrl <- Sys.getenv("DOCPLEXCLOUD_URL", 
                      unset="https://api-oaas.docloud.ibmcloud.com/job_manager/rest/v1/")


# The default api key
# This is the api key to use when submitting jobs to DOcplexcloud
# This uses your env variable DOCPLEXCLOUD_KEY if it has been set, otherwise
# it uses the key in the unset part.
# If left blank, user will have to input their key in the UI
apiKey = Sys.getenv("DOCPLEXCLOUD_KEY",
                           unset =)

# install the docplexcloud-R-client
if (!require('docplexcloud')){
  if(!require(devtools)){
    install.packages("devtools")
  }
  library(devtools)
  install_github("IBMDecisionOptimization/DOcplexcloud-R-client")
}

require('docplexcloud')

library(shiny)

ui <- fluidPage(
  sidebarLayout(
    sidebarPanel(
    # Give the page a title
    titlePanel("Nurse Scheduling"),
      sliderInput(inputId = "num",
                label = "Max number of hours per nurse",
                value = 60, min = 40, max = 150),
      passwordInput("api_key", "CPLEX key", value = defaultApiKey),
      actionButton(inputId = "run_cplex", label = "Run Optimization")
      ),
    mainPanel(
      tabsetPanel(
        tabPanel("KPIs",
                 titlePanel("Weights for KPIs"),
                 sliderInput(inputId = "Weight_Salary",
                             label = "Weekly Salary Cost",
                             value = 1, min = 1, max = 10),
                 sliderInput(inputId = "Weight_Fairness",
                             label = "Hours Allocation Fairness",
                             value = 1, min = 1, max = 10),
                 tableOutput("kpi_view"),
                 plotOutput("bar")
        ),
        tabPanel("Nurse Weekly Hours",
          tableOutput("view")
        )
        
      )
      )
    )
)

server <- function(input, output) {
  observeEvent(input$run_cplex, {
    num_hr <- input$num
    weight_salary <- input$Weight_Salary
    weight_fairness <- input$Weight_Fairness
    
    apiKey = defaultApiKey
    if (apiKey == "") {
      apiKey = input$api_key
    }
    
    cplexModel <- paste(readLines("nurses_w_data.py"), collapse = '\n')
    
    params <- paste("num_hr, weight_salary, weight_fairness", "\n",toString(num_hr), ",",toString(weight_salary),",",toString(weight_fairness))
    write(params, "params.csv")
    
    client <- DOcplexcloudClient$new(url=baseUrl, key=apiKey, verbose=TRUE)
    
    job <- client$submitJob(addAttachment(name="nurses_w_data.py",
                                          data=charToRaw(cplexModel)),
                            addAttachment(name="params.csv",
                                          data=charToRaw(params)))
    
    Nurse_hours = rawToChar(client$getAttachment(job, "nurse_hours.csv"))
    KPIs = rawToChar(client$getAttachment(job, "KPIs.csv"))
    
    client$deleteJob(job)
    # create the results/ dir if needed
    write(Nurse_hours, "downloded_nurse_hours.csv")
    write(KPIs, "downloded_KPIs.csv")
    
    Nurse_hours_results <- read.csv("downloded_nurse_hours.csv")
    KPIs_results <- read.csv("downloded_KPIs.csv")
    
    output$view <- renderTable(Nurse_hours_results)
    output$kpi_view <- renderTable(KPIs_results)
  
      output$bar <- renderPlot({
        barplot(Nurse_hours_results[ ,c("Hours")],
                ylab="Weekly Hours",
                names.arg = Nurse_hours_results[ ,c("Name")],
                las=2)
    })
  })
  
}

shinyApp(ui = ui, server = server)
